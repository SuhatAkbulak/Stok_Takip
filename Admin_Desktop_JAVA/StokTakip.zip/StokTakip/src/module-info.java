module StokTakip {
	requires java.desktop;
	requires java.net.http;
	requires java.json;
}